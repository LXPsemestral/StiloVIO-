const productos = [
  { id: 1, nombre: "Hoodie wolfgrey", precio: 59990, imagen: "img/hoodiewolfgrey.jpg" },
  { id: 2, nombre: "Hoodie burgundy", precio: 59990, imagen: "img/hoodieburgundy.jpg" },
  { id: 3, nombre: "T shirt navy", precio: 29990, imagen: "img/tshirtnavy.jpg" },
  { id: 4, nombre: "Jacket rain black", precio: 89990, imagen: "img/jacketrainblack.jpg" },
  { id: 5, nombre: "Hoodie light blue", precio: 59990, imagen: "img/hoodielightblue.jpg" },
  { id: 6, nombre: "T shirt blackandblack", precio: 29990, imagen: "img/tshirtblackandblack.jpg" },
  { id: 7, nombre: "T shirt white", precio: 29990, imagen: "img/tshirtwhite.jpg" },
  { id: 8, nombre: "Hoodie taupe", precio: 59990, imagen: "img/hoodietaupe.jpg" },
  { id: 9, nombre: "Hoodie navy", precio: 59990, imagen: "img/hoodienavy.jpg" },
  { id: 10, nombre: "Hoodie purple", precio: 59990, imagen: "img/hoodielightpurple.jpg" },
  { id: 11, nombre: "Dress black", precio: 49990, imagen: "img/vestidoblack.jpg" },
  { id: 12, nombre: "Jeans baggy", precio: 39990, imagen: "img/jeansbaggy.jpg" }
];

function precioCLP(valor) {
  return "$" + valor.toLocaleString("es-CL");
}
function obtenerCarrito() {
  try {
    const guardado = JSON.parse(localStorage.getItem("stilovio-carrito"));
    return Array.isArray(guardado) ? guardado : [];
  } catch (error) {
    return [];
  }
}

function guardarCarrito(carrito) {
  localStorage.setItem("stilovio-carrito", JSON.stringify(carrito));
  actualizarContador();
}

function actualizarContador() {
  const cantidad = obtenerCarrito().length;
  document.querySelectorAll(".contador").forEach(function (elemento) {
    elemento.textContent = cantidad;
  });
}

function agregarAlCarrito(id) {
  const carrito = obtenerCarrito();
  carrito.push(id);
  guardarCarrito(carrito);
  const aviso = document.getElementById("aviso");
  if (aviso) aviso.textContent = "El producto se agrego al carrito";
}

function mostrarProductos(idContenedor, lista) {
  const contenedor = document.getElementById(idContenedor);
  if (!contenedor) return;

  contenedor.innerHTML = "";
  lista.forEach(function (producto) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "tarjeta";
    tarjeta.innerHTML = `
      <img src="${producto.imagen}" alt="${producto.nombre}">
      <h3>${producto.nombre}</h3>
      <p class="precio">${precioCLP(producto.precio)}</p>
      <button class="boton" type="button">Agregar al carrito</button>
    `;
    tarjeta.querySelector("button").addEventListener("click", function () {
      agregarAlCarrito(producto.id);
    });
    contenedor.appendChild(tarjeta);
  });
}

document.addEventListener("DOMContentLoaded", function () {
  mostrarProductos("contenedor-productos", productos);
  mostrarProductos("destacados", productos.slice(0, 3));
  actualizarContador();
});
