function mostrarCarrito() {
  const contenedor = document.getElementById("lista-carrito");
  const carrito = obtenerCarrito();
  contenedor.innerHTML = "";
  let total = 0;

  if (carrito.length === 0) {
    contenedor.innerHTML = '<p>Tu carrito esta vacio. <a href="productos.html">Ver productos</a></p>';
  }

  carrito.forEach(function (id, posicion) {
    const producto = productos.find(function (item) {
      return item.id === id;
    });
    if (!producto) return;

    total += producto.precio;
    const fila = document.createElement("article");
    fila.className = "fila-carrito";
    fila.innerHTML = `
      <img src="${producto.imagen}" alt="${producto.nombre}">
      <strong>${producto.nombre}</strong>
      <span>${precioCLP(producto.precio)}</span>
      <button type="button">Quitar</button>
    `;
    fila.querySelector("button").addEventListener("click", function () {
      const nuevoCarrito = obtenerCarrito();
      nuevoCarrito.splice(posicion, 1);
      guardarCarrito(nuevoCarrito);
      mostrarCarrito();
    });
    contenedor.appendChild(fila);
  });

  document.getElementById("total").textContent = "Total: " + precioCLP(total);
}

document.addEventListener("DOMContentLoaded", function () {
  mostrarCarrito();
  document.getElementById("vaciar").addEventListener("click", function () {
    guardarCarrito([]);
    mostrarCarrito();
  });
});
