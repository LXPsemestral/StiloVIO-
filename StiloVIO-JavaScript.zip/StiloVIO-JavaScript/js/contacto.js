const formulario = document.getElementById("formulario");
const campos = ["nombre", "correo", "mensaje"];
const dominiosPermitidos = ["duoc.cl", "profesor.duoc.cl", "gmail.com"];

function validarCampo(nombreCampo) {
  const campo = document.getElementById(nombreCampo);
  const valor = campo.value.trim();
  let error = "";

  if (valor === "") {
    error = "Este campo es obligatorio.";
  } else if (nombreCampo === "nombre") {
    if (valor.length < 3) error = "Escribe tu nombre completo (minimo 3 caracteres).";
    if (valor.length > 100) error = "Maximo 100 caracteres.";
  } else if (nombreCampo === "correo") {
    const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const dominio = valor.split("@")[1]?.toLowerCase();
    if (valor.length > 100) {
      error = "Maximo 100 caracteres.";
    } else if (!formatoCorreo.test(valor)) {
      error = "Escribe un correo valido, por ejemplo: nombre@duoc.cl.";
    } else if (!dominiosPermitidos.includes(dominio)) {
      error = "Solo se aceptan @duoc.cl, @profesor.duoc.cl o @gmail.com.";
    }
  } else if (nombreCampo === "mensaje") {
    if (valor.length < 10) error = "Escribe un mensaje de al menos 10 caracteres.";
    if (valor.length > 500) error = "Maximo 500 caracteres.";
  }

  document.getElementById("error-" + nombreCampo).textContent = error;
  campo.classList.toggle("invalido", error !== "");
  campo.classList.toggle("correcto", error === "");
  campo.setAttribute("aria-invalid", String(error !== ""));
  return error === "";
}

campos.forEach(function (nombreCampo) {
  document.getElementById(nombreCampo).addEventListener("input", function () {
    validarCampo(nombreCampo);
    if (nombreCampo === "mensaje") {
      document.getElementById("contador-mensaje").textContent =
        document.getElementById("mensaje").value.length + "/500 caracteres";
    }
  });
});

formulario.addEventListener("submit", function (evento) {
  evento.preventDefault();
  const resultados = campos.map(validarCampo);
  const resultado = document.getElementById("resultado");

  if (resultados.every(Boolean)) {
    resultado.textContent = "Datos correctos! Mensaje validado.";
    formulario.reset();
    campos.forEach(function (nombreCampo) {
      const campo = document.getElementById(nombreCampo);
      campo.classList.remove("correcto", "invalido");
      document.getElementById("error-" + nombreCampo).textContent = "";
      campo.setAttribute("aria-invalid", "false");
    });
    document.getElementById("contador-mensaje").textContent = "0/500 caracteres";
  } else {
    resultado.textContent = "Revisa los campos marcados e intentalo nuevamente.";
    const primerError = campos.find(function (nombreCampo, indice) {
      return !resultados[indice];
    });
    document.getElementById(primerError).focus();
  }
});
