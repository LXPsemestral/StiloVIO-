# Documento de Especificación de Requisitos de Software (ERS V2)
## Proyecto: StiloVIO

### 1. Introducción
StiloVIO es una tienda online de ropa. Esta versión actualiza el frontend a React, agrega navegación entre nuevas vistas, persistencia local de datos y un panel administrativo. El sistema se desarrolla con fines académicos.

### 2. Objetivo
Permitir que los usuarios revisen el catálogo, busquen y filtren productos, administren un carrito y completen un flujo de compra simulado. Permitir al administrador gestionar los productos mediante operaciones CRUD.

### 3. Alcance
Incluye interfaz pública de tienda, categorías, ofertas, carrito, checkout, resultado de compra, contacto y panel administrativo. No incluye backend, autenticación real, pasarela de pago, despacho real ni envío efectivo de correos.

### 4. Usuarios
- Cliente: navega por la tienda, busca productos, agrega prendas al carrito y completa el checkout de demostración.
- Administrador: crea, consulta, modifica y elimina productos desde el panel administrativo.

### 5. Requerimientos funcionales
| Código | Requerimiento |
|---|---|
| RF01 | El sistema debe mostrar la página de inicio y productos destacados. |
| RF02 | El sistema debe mostrar el catálogo de productos. |
| RF03 | El usuario debe poder buscar productos por nombre. |
| RF04 | El usuario debe poder filtrar productos por categoría, también al llegar desde la vista de categorías mediante la URL (`?categoria=`). |
| RF05 | El sistema debe mostrar una vista de categorías. |
| RF06 | El sistema debe mostrar los productos marcados en oferta. |
| RF07 | El usuario debe poder agregar productos al carrito. |
| RF08 | El usuario debe poder quitar productos y vaciar el carrito. |
| RF09 | El sistema debe calcular el total del carrito considerando el precio de oferta cuando corresponda. |
| RF10 | El usuario debe poder ingresar nombre, correo, dirección y comuna en el checkout. |
| RF11 | El sistema debe mostrar una confirmación de compra simulada. |
| RF12 | El sistema debe disponer de una vista informativa de pago fallido. |
| RF13 | El administrador debe poder crear productos. |
| RF14 | El administrador debe poder consultar el catálogo en el panel. |
| RF15 | El administrador debe poder actualizar productos. |
| RF16 | El administrador debe poder eliminar productos. |
| RF17 | El sistema debe conservar productos y carrito en el almacenamiento local del navegador. |
| RF18 | El sistema debe mostrar una vista de contacto con validación básica de campos. |
| RF19 | Al añadir un producto al carrito, el sistema debe confirmarlo con un aviso animado ("¡Producto añadido con éxito!"), una confirmación visual en el botón y una animación del contador del carrito. |
| RF20 | Al quitar un producto o vaciar el carrito, el sistema debe animar la salida de los elementos y mostrar un aviso de confirmación. |

### 6. Requerimientos no funcionales
- RNF01: La interfaz debe adaptarse a móviles, tabletas y escritorio mediante Bootstrap.
- RNF02: La aplicación debe estar organizada en componentes React reutilizables.
- RNF03: Cada componente debe mantener una responsabilidad clara.
- RNF04: Los datos de productos y carrito deben persistir al recargar la página en el mismo navegador.
- RNF05: Los componentes y operaciones principales deben contar con pruebas unitarias (Jasmine/Karma) y un reporte de cobertura de código.
- RNF06: La interfaz debe utilizar etiquetas, textos alternativos y controles comprensibles.
- RNF07: Las animaciones (menú, avisos y carrito) deben ser suaves, de corta duración y respetar la preferencia del sistema "reducir movimiento" (`prefers-reduced-motion`).

### 7. Herramientas y tecnologías
- React 18 y JavaScript.
- Vite para desarrollo y compilación.
- React Router para navegación.
- Bootstrap 5 para diseño responsivo.
- localStorage como persistencia local simulada.
- Jasmine y Karma para pruebas unitarias.
- Visual Studio Code y Git/GitHub para desarrollo colaborativo.

### 8. Vistas y navegación
Inicio → Productos / Categorías / Ofertas / Carrito / Contacto / Administración.
Carrito → Checkout → Compra exitosa.
La vista de pago fallido está disponible como ruta independiente `/pago-fallido`.

### 9. Datos principales
Producto: id, nombre, precio, categoría, imagen, indicador de oferta, precio de oferta opcional y destacado opcional.
Carrito: lista de identificadores de productos.
Pedido de demostración: nombre, correo, dirección, comuna y opción de entrega.

### 10. Restricciones y supuestos
- Los datos se almacenan en el navegador del usuario y no se sincronizan entre dispositivos.
- No existe backend ni base de datos remota.
- El checkout no procesa pagos ni genera una orden comercial real.
- El panel administrativo no cuenta con autenticación; es una vista demostrativa.
- El resultado de compra exitosa es una simulación para probar el flujo frontend.

### 11. Criterios de aceptación
- Se visualizan las vistas principales y la navegación funciona.
- El usuario puede buscar, filtrar y agregar productos al carrito.
- El carrito permite quitar elementos, vaciarse y calcular el total, mostrando animaciones y avisos de confirmación.
- Al añadir un producto aparece el aviso "¡Producto añadido con éxito!" y el contador del carrito se actualiza.
- El checkout valida los campos obligatorios y presenta confirmación.
- El panel permite crear, editar y eliminar productos.
- Los cambios se conservan al recargar el navegador.
- Las pruebas Jasmine se ejecutan mediante Karma.
