# Guion breve de presentación - StiloVIO Evaluación 2

## 1. Introducción
Nuestro proyecto es StiloVIO, una tienda online de ropa. Para esta segunda entrega actualizamos el frontend desde HTML a React y agregamos nuevas vistas y funciones.

## 2. Tecnologías
Utilizamos React para construir componentes reutilizables, React Router para navegar entre vistas, Bootstrap para el diseño responsivo y JavaScript para manejar los datos. La persistencia se realiza mediante localStorage.

## 3. Tienda pública
La página de inicio muestra productos destacados. En el catálogo se puede buscar por nombre y filtrar por categoría. También agregamos vistas separadas de categorías y ofertas.

## 4. Carrito y compra
El usuario puede agregar o quitar productos, vaciar el carrito y revisar el total. Cada acción muestra un aviso animado (componente `Toast`) y el carrito anima la salida de los productos. Luego completa sus datos de entrega en el checkout. La compra es una simulación académica y no realiza cobros reales.

## 5. Administración
Creamos un panel administrativo donde se pueden agregar, editar y eliminar productos. Los cambios quedan guardados en el navegador.

## 6. Testing
Configuramos Jasmine y Karma con webpack y Babel para ejecutar las pruebas en Chrome. Tenemos 31 pruebas: operaciones CRUD, cálculo de precios y total del carrito, y componentes (ProductCard, ProductGrid, Cart, Checkout, Products, Toast y Header) comprobando renderizado, props, estado y eventos. Usamos mocks: espías sobre localStorage y funciones simuladas con `jasmine.createSpy` para los callbacks y reloj simulado (`jasmine.clock()`) para probar las animaciones temporizadas. La cobertura se genera con karma-coverage en `coverage/index.html`.

## 7. Cierre
Con estos cambios el proyecto cumple la estructura frontend solicitada para esta etapa. Como alcance futuro se podría conectar un backend, incorporar autenticación administrativa y una pasarela de pago real.
