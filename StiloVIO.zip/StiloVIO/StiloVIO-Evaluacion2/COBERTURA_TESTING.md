# Documento de cobertura y análisis de testing - StiloVIO

## 1. Objetivo
Verificar la lógica de datos, el cálculo del carrito y el comportamiento de los componentes React (renderizado, props, estado, eventos y manipulación del DOM) mediante Jasmine y Karma.

## 2. Herramientas y configuración del entorno
| Herramienta | Rol |
|---|---|
| Jasmine (`jasmine-core`) | Define las pruebas (`describe`/`it`), expectativas y espías (`spyOn`, `jasmine.createSpy`). |
| Karma (`karma`, `karma-jasmine`) | Ejecuta las pruebas dentro de un navegador real. |
| Chrome Headless (`karma-chrome-launcher`) | Navegador donde corren las pruebas (`npm test`). `npm run test:browser` abre Chrome visible. |
| `karma-webpack` + `babel-loader` | Empaqueta cada `*.spec.js` junto con los componentes y transpila JSX. |
| `babel-plugin-istanbul` + `karma-coverage` | Instrumenta el código y genera el reporte de cobertura en `coverage/index.html`. |
| `karma-jasmine-html-reporter` | Muestra los resultados en la ventana del navegador. |

Archivo de configuración: `karma.conf.cjs`. Pruebas en `src/tests/` (`datos.spec.js`, `componentes.spec.js`, `utils.js`).

## 3. Casos implementados (31 pruebas)
| ID | Área | Qué verifica |
|---|---|---|
| TU01 | Datos / lectura | Catálogo inicial de 12 productos sin datos guardados. |
| TU02 | Datos / crear | Un producto nuevo queda guardado (13 productos). |
| TU03 | Datos / actualizar | El cambio de nombre se conserva. |
| TU04 | Datos / eliminar | El producto eliminado deja de existir. |
| TU05 | Datos / restaurar | Se recuperan los 12 productos iniciales. |
| TU06 | **Mock** | Espía sobre `Storage.prototype.setItem`: se guarda con la clave `stilovio-productos-v2`. |
| TU07 | **Mock** | `Storage.prototype.getItem` simulado con JSON roto: se usan los valores por defecto sin fallar. |
| TU08 | Lógica | `precioFinal` sin oferta. |
| TU09 | Lógica | `precioFinal` con oferta. |
| TU10 | Lógica | `calcularTotal` mezcla normales y oferta e ignora ids inexistentes (109.980). |
| TU11 | Carrito | Agregar, quitar por posición y vaciar con persistencia. |
| TC01 | ProductCard | Muestra nombre y precio recibidos por props. |
| TC02 | ProductCard / evento | `onAdd` (espía) se llama una vez con el id correcto. |
| TC03 | ProductCard / condicional | Etiqueta "Oferta", precio tachado y precio de oferta. |
| TC04 | ProductGrid | Mensaje cuando no hay productos. |
| TC05 | ProductGrid | Una tarjeta por producto. |
| TC06 | Cart | Mensaje de carrito vacío. |
| TC07 | Cart / animación | Total correcto (129.970); al presionar "Quitar" la fila inicia su salida animada y `onRemove(0)` se llama al terminar (reloj simulado). |
| TC08 | Checkout | Con campos vacíos muestra error y no llama a `onComplete`. |
| TC09 | Checkout / estado | Escribir actualiza el estado y se entregan los datos a `onComplete`. |
| TC10 | Products / estado | Búsqueda por nombre ("hoodie" → 6 resultados). |
| TC11 | Products / estado | Filtro por categoría ("Poleras" → 3 resultados). |
| TC12 | Products / URL | `?categoria=Chaquetas` aplica el filtro inicial (1 resultado). |
| TC13 | Cart / animación | "Vaciar carrito" anima todas las filas, deshabilita los botones y llama a `onClear` al terminar. |
| TC14 | Toast | Muestra "¡Producto añadido con éxito!", el enlace al carrito, sale animado y llama a `onCerrar` solo. |
| TC15 | ProductCard / estado | Tras el clic el botón muestra "¡Añadido!" y vuelve a su texto original (temporizador simulado). |
| TC16 | ProductCard / estado | Un segundo clic seguido reinicia el temporizador del mensaje. |
| TC17 | Toast | Aviso de tipo "quitar" con su estilo y cierre inmediato con el botón ×. |
| TC18 | Toast | Sin aviso no se renderiza ninguna tarjeta. |
| TC19 | Header | Muestra la cantidad en el contador y los 6 enlaces; no rebota al cargar. |
| TC20 | Header / estado | El contador rebota cuando cambia la cantidad y luego se detiene. |

## 4. Uso de mocks
- **Espías (`spyOn`)** sobre `localStorage` para aislar la lógica de datos del navegador y simular datos corruptos (TU06, TU07).
- **Funciones simuladas (`jasmine.createSpy`)** para reemplazar callbacks recibidos por props (`onAdd`, `onRemove`, `onClear`, `onComplete`, `onCerrar`) y comprobar cuántas veces y con qué argumentos se invocan (TC02, TC07, TC08, TC09, TC13, TC14, TC17).
- **Reloj simulado (`jasmine.clock()`)** para probar las animaciones temporizadas (salida de filas del carrito, aviso que se cierra solo, botón "¡Añadido!", contador que rebota) sin esperar tiempo real (TC07, TC13–TC16, TC19–TC20).
- `MemoryRouter` de React Router simula la navegación sin depender de la URL real del navegador.

## 5. Ejecución
1. `npm install`
2. `npm test` → resumen en terminal y reporte en `coverage/index.html`.
3. `npm run test:browser` → ventana de Chrome con el reporte de Jasmine.

## 6. Resultados y cobertura
Resultado de `npm test` (Chrome Headless, Karma 6.4.4):

- Pruebas ejecutadas / exitosas: **31 / 31**
- Statements: 100% (135/135) · Branches: 100% (60/60) · Functions: 100% (55/55) · Lines: 100% (107/107)

**Alcance del porcentaje:** el reporte mide únicamente los archivos que las pruebas importan: `productos.js`, `carrito.js`, `ProductCard`, `ProductGrid`, `Toast`, `Header`, `Cart`, `Checkout` y `Products`. Las vistas `Admin`, `Contact`, `Home`, `Offers`, `Categories`, `OrderResult`, `Footer` y `App` no tienen pruebas y no entran en ese 100%. Por eso se indica como cobertura de los módulos probados, no del proyecto completo.

Durante la ejecución Karma muestra avisos 404 de imágenes (`/img/...`) porque su servidor no sirve la carpeta `public`; no afectan los resultados. Los avisos de React Router (v7 future flags) son informativos.

## 7. Análisis y limitaciones
- Quedan cubiertas la capa de datos (`productos.js`, `carrito.js`) y los componentes `ProductCard`, `ProductGrid`, `Toast`, `Header`, `Cart`, `Checkout` y `Products`.
- No tienen pruebas dedicadas `Admin`, `Contact` y `App`; se cubren manualmente. Son ampliaciones posibles.
- Las animaciones CSS (keyframes) no se prueban visualmente: se verifican los cambios de estado y de clases que las disparan, y el resultado visual se revisa manualmente.
- La responsividad (Bootstrap) se verifica manualmente con DevTools; no se automatiza.
- La persistencia usa `localStorage` y el checkout es simulado, por lo que no se prueba una pasarela real.
