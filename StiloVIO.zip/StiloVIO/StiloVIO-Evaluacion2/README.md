# StiloVIO - Evaluación Parcial 2

Tienda de ropa desarrollada con React, JavaScript y Bootstrap. Incluye catálogo, categorías, ofertas, carrito, checkout de demostración y panel administrativo.

## Requisitos
- Node.js 18 o superior
- npm
- Google Chrome (para ejecutar Karma)

## Ejecutar el proyecto
1. Descomprime el proyecto.
2. Abre la carpeta `StiloVIO-Evaluacion2` en Visual Studio Code.
3. Abre la terminal dentro de esa carpeta.
4. Ejecuta `npm install`.
5. Ejecuta `npm run dev`.
6. Abre en el navegador la dirección local que indique Vite (normalmente `http://localhost:5173`).

## Compilar
Ejecuta `npm run build`. Los archivos listos para publicar quedan en `dist/`.

## Ejecutar pruebas
- `npm test`: Karma ejecuta las pruebas Jasmine en Chrome Headless, muestra el resumen en la terminal y genera el reporte de cobertura en `coverage/index.html`.
- `npm run test:browser`: abre una ventana visible de Chrome con el reporte de Jasmine (útil para la presentación en vivo).

## Funcionalidades
- Navegación con React Router.
- Catálogo de productos y tarjetas reutilizables.
- Búsqueda y filtro por categoría.
- Vistas de categorías y ofertas.
- Carrito con agregar, quitar y vaciar, con avisos y animaciones (aviso flotante, contador que rebota, salida animada de filas).
- Menú superior con efecto hover suave.
- Checkout de demostración y resultado exitoso.
- Vista de pago fallido disponible en `/pago-fallido`.
- Panel administrativo con operaciones CRUD.
- Persistencia local mediante `localStorage`.
- Diseño responsivo con Bootstrap 5.

## Persistencia
Los productos se guardan en `localStorage` bajo `stilovio-productos-v2` y el carrito bajo `stilovio-carrito-v2`. Es una persistencia local del navegador para fines académicos; no corresponde a un servidor ni a una base de datos real.

## Estructura
- `src/components/`: componentes reutilizables (`Header`, `Footer`, `ProductCard`, `ProductGrid`, `Toast`).
- `src/pages/`: vistas de la tienda.
- `src/data/`: datos iniciales y operaciones CRUD/persistencia.
- `src/tests/`: pruebas unitarias Jasmine (`datos.spec.js`, `componentes.spec.js`) y utilidades (`utils.js`).
- `karma.conf.cjs`: configuración de Karma (Jasmine, webpack, Babel, cobertura).
- `vite.config.js`: configuración de Vite con el plugin de React.
- `public/img/`: fotografías originales de StiloVIO.
- `ERS_V2.md`: especificación de requisitos actualizada.
- `COBERTURA_TESTING.md`: propuesta y análisis de pruebas.
