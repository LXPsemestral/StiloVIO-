// Configuración de Karma + Jasmine (pruebas unitarias del frontend React).
// - karma-webpack empaqueta cada *.spec.js junto con los componentes que importa.
// - babel-loader transpila JSX; babel-plugin-istanbul instrumenta el código para medir cobertura.
// - karma-coverage genera el reporte en /coverage (abrir coverage/index.html).
module.exports = function (config) {
  config.set({
    frameworks: ["jasmine", "webpack"],
    files: [{ pattern: "src/tests/**/*.spec.js", watched: false }],
    preprocessors: { "src/tests/**/*.spec.js": ["webpack"] },
    webpack: {
      mode: "development",
      devtool: false,
      module: {
        rules: [
          {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            resolve: { fullySpecified: false },
            use: {
              loader: "babel-loader",
              options: {
                plugins: [["istanbul", { include: ["src/**/*.{js,jsx}"], exclude: ["src/tests/**", "src/main.jsx"] }]]
              }
            }
          }
        ]
      },
      resolve: { extensions: [".js", ".jsx"] }
    },
    reporters: ["progress", "kjhtml", "coverage"],
    coverageReporter: {
      dir: "coverage",
      subdir: ".",
      reporters: [{ type: "html" }, { type: "text-summary" }, { type: "lcovonly" }]
    },
    browsers: ["ChromeHeadlessCI"],
    customLaunchers: {
      ChromeHeadlessCI: { base: "ChromeHeadless", flags: ["--no-sandbox"] }
    },
    client: { clearContext: false },
    singleRun: true
  });
};
