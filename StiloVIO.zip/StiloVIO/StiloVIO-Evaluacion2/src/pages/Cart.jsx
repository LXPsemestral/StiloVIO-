import { useState } from "react";
import { Link } from "react-router-dom";
import { precioCLP, precioFinal } from "../data/productos";
import { calcularTotal } from "../data/carrito";

// Tiempos de las animaciones (deben coincidir con row-out en styles.css).
const DURACION_SALIDA = 350;
const ESCALONADO = 70;
const MAX_ESCALONADO = 6;

export default function Cart({ carrito, productos, onRemove, onClear }) {
  // saliendo: null | { tipo: "uno", clave } | { tipo: "todos" }  -> controla la animación de salida
  const [saliendo, setSaliendo] = useState(null);

  // Clave estable por fila (id + nº de repetición) para que al quitar una no se re-animen las demás.
  const repetidos = {};
  const filas = carrito
    .map((id, pos) => ({ producto: productos.find(p => p.id === id), pos }))
    .filter(x => x.producto)
    .map((fila, indice) => {
      const id = fila.producto.id;
      repetidos[id] = (repetidos[id] || 0) + 1;
      return { ...fila, indice, clave: `${id}-${repetidos[id]}` };
    });
  const total = calcularTotal(carrito, productos);

  // Primero se anima la salida y, al terminar, se avisa al padre para quitar el producto.
  function quitar(fila) {
    setSaliendo({ tipo: "uno", clave: fila.clave });
    setTimeout(() => { setSaliendo(null); onRemove(fila.pos); }, DURACION_SALIDA);
  }

  function vaciar() {
    setSaliendo({ tipo: "todos" });
    const espera = DURACION_SALIDA + Math.min(filas.length - 1, MAX_ESCALONADO) * ESCALONADO;
    setTimeout(() => { setSaliendo(null); onClear(); }, espera);
  }

  return (
    <main className="container py-5">
      <p className="eyebrow">Tu selección</p>
      <h1>Carrito de compra</h1>
      {!filas.length ? (
        <div className="empty-state my-4"><span className="empty-cart-icon" aria-hidden="true">🛒</span>Tu carrito está vacío. <Link to="/productos">Ver productos</Link></div>
      ) : (
        <>
          <div className="list-group my-4">
            {filas.map(fila => {
              const { producto } = fila;
              const sale = saliendo && (saliendo.tipo === "todos" || saliendo.clave === fila.clave);
              const retraso = saliendo && saliendo.tipo === "todos" ? Math.min(fila.indice, MAX_ESCALONADO) : 0;
              return (
                <div className={`list-group-item cart-row${sale ? " cart-row-leaving" : ""}`} style={{ "--i": Math.min(fila.indice, MAX_ESCALONADO), "--out": retraso }} key={fila.clave}>
                  <img src={producto.imagen} alt={producto.nombre} />
                  <div className="flex-grow-1">
                    <strong>{producto.nombre}</strong>
                    <div className="text-muted">{producto.categoria}</div>
                  </div>
                  <strong>{precioCLP(precioFinal(producto))}</strong>
                  <button className="btn btn-sm btn-outline-danger" disabled={Boolean(saliendo)} onClick={() => quitar(fila)}>Quitar</button>
                </div>
              );
            })}
          </div>
          <div className="d-flex flex-wrap justify-content-between align-items-center gap-3">
            <h2 key={total} className="cart-total">Total: {precioCLP(total)}</h2>
            <div className="d-flex gap-2">
              <button className="btn btn-outline-secondary" disabled={Boolean(saliendo)} onClick={vaciar}>Vaciar carrito</button>
              <Link className="btn btn-brand" to="/checkout">Continuar compra</Link>
            </div>
          </div>
        </>
      )}
    </main>
  );
}
