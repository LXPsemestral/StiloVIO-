import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import ProductGrid from "../components/ProductGrid";

export default function Products({ productos, onAdd }) {
  const [params] = useSearchParams();
  const [busqueda, setBusqueda] = useState("");
  // Si se llega desde /categorias, la URL trae ?categoria=Hoodies y se usa como filtro inicial.
  const [categoria, setCategoria] = useState(params.get("categoria") || "Todas");
  const categorias = ["Todas", ...new Set(productos.map(p => p.categoria))];
  const filtrados = useMemo(
    () => productos.filter(p => p.nombre.toLowerCase().includes(busqueda.toLowerCase()) && (categoria === "Todas" || p.categoria === categoria)),
    [productos, busqueda, categoria]
  );
  return (
    <main className="container py-5">
      <p className="eyebrow">Catálogo</p>
      <h1>Nuestros productos</h1>
      <p>Encuentra prendas para tu estilo.</p>
      <div className="row g-3 my-3">
        <div className="col-md-7">
          <input className="form-control" value={busqueda} onChange={e => setBusqueda(e.target.value)} placeholder="Buscar producto..." aria-label="Buscar producto" />
        </div>
        <div className="col-md-5">
          <select className="form-select" value={categoria} onChange={e => setCategoria(e.target.value)} aria-label="Filtrar por categoría">
            {categorias.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>
      <p className="text-muted">{filtrados.length} producto(s) encontrados</p>
      <ProductGrid productos={filtrados} onAdd={onAdd} />
    </main>
  );
}
