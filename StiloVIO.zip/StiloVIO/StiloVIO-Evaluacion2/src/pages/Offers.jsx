import ProductGrid from "../components/ProductGrid";
export default function Offers({ productos, onAdd }) {
  return <main className="container py-5"><p className="eyebrow">Precios especiales</p><h1>Ofertas</h1><p>Revisa los productos con precio promocional.</p><ProductGrid productos={productos.filter(p=>p.oferta)} onAdd={onAdd}/></main>;
}
