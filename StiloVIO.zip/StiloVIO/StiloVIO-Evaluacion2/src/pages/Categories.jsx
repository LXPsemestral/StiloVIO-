import { Link } from "react-router-dom";
export default function Categories({ productos }) {
  const categorias = [...new Set(productos.map(p=>p.categoria))];
  return <main className="container py-5"><p className="eyebrow">Explora la tienda</p><h1>Categorías</h1><div className="row g-4 mt-2">{categorias.map(c=><div className="col-12 col-sm-6 col-lg-4" key={c}><Link className="category-tile" to={`/productos?categoria=${encodeURIComponent(c)}`}><h2>{c}</h2><span>{productos.filter(p=>p.categoria===c).length} productos</span></Link></div>)}</div></main>;
}
