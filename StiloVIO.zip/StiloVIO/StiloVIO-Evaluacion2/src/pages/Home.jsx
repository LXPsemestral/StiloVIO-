import { Link } from "react-router-dom";
import ProductGrid from "../components/ProductGrid";

export default function Home({ productos, onAdd }) {
  return <>
    <section className="hero"><div className="container py-5"><div className="row align-items-center g-4"><div className="col-lg-6"><p className="eyebrow">Ropa para tu día a día</p><h1 className="display-4 fw-bold">Bienvenido a StiloVIO</h1><p className="lead">Descubre hoodies, poleras y chaquetas para vestir a tu estilo.</p><Link className="btn btn-brand btn-lg" to="/productos">Ver catálogo</Link></div><div className="col-lg-6"><img className="hero-image" src="/img/hoodiewolfgrey.jpg" alt="Hoodie Wolfgrey" /></div></div></div></section>
    <section className="container py-5"><div className="d-flex justify-content-between align-items-end mb-4"><div><p className="eyebrow">Selección de la tienda</p><h2>Productos destacados</h2></div><Link to="/productos">Ver todos</Link></div><ProductGrid productos={productos.filter(p => p.destacado).slice(0,4)} onAdd={onAdd}/></section>
  </>;
}
