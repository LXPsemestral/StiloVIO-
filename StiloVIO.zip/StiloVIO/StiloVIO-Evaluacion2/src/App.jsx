import { useEffect, useRef, useState } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Toast from "./components/Toast";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Categories from "./pages/Categories";
import Offers from "./pages/Offers";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Contact from "./pages/Contact";
import Admin from "./pages/Admin";
import { Success, Failure } from "./pages/OrderResult";
import { obtenerProductos, crearProducto, actualizarProducto, eliminarProducto } from "./data/productos";
import { obtenerCarrito, agregarCarrito, quitarDelCarrito, vaciarCarrito } from "./data/carrito";

function AppContent() {
 const [productos,setProductos]=useState(obtenerProductos);
 const [carrito,setCarrito]=useState(obtenerCarrito);
 const [pedido,setPedido]=useState(null);
 const location=useLocation();
 useEffect(()=>{window.scrollTo(0,0);},[location.pathname]);
 const cantidad=carrito.length;
 const [aviso,setAviso]=useState(null);
 const contadorAvisos=useRef(0);
 // Muestra un aviso flotante animado (ver components/Toast.jsx). Cada aviso lleva un id nuevo para reiniciar la animación.
 function notificar(tipo,titulo,texto,imagen,enlace){contadorAvisos.current+=1;setAviso({id:contadorAvisos.current,tipo,titulo,texto,imagen,enlace});}
 function add(id){
  const nuevo=agregarCarrito(id);setCarrito([...nuevo]);
  const producto=productos.find(p=>p.id===id);
  if(producto)notificar("exito","¡Producto añadido con éxito!",`${producto.nombre} · ${nuevo.length===1?"1 producto":`${nuevo.length} productos`} en tu carrito`,producto.imagen,{to:"/carrito",texto:"Ver carrito →"});
 }
 function remove(pos){
  const producto=productos.find(p=>p.id===carrito[pos]);
  const nuevo=quitarDelCarrito(pos);setCarrito([...nuevo]);
  if(producto)notificar("quitar","Producto quitado",`${producto.nombre} salió de tu carrito`,producto.imagen);
 }
 function clear(){vaciarCarrito();setCarrito([]);}
 function clearFromCart(){clear();notificar("quitar","Carrito vaciado","Quitaste todos los productos de tu carrito");}
 function create(datos){const nuevo=crearProducto(datos);setProductos([...obtenerProductos()]);return nuevo;}
 function update(id,datos){actualizarProducto(id,datos);setProductos([...obtenerProductos()]);}
 function removeProduct(id){eliminarProducto(id);setProductos([...obtenerProductos()]);}
 function complete(datos){setPedido(datos);clear();}
 return <><Header cantidad={cantidad}/><Toast aviso={aviso} onCerrar={()=>setAviso(null)}/><Routes>
  <Route path="/" element={<Home productos={productos} onAdd={add}/>}/>
  <Route path="/productos" element={<Products productos={productos} onAdd={add}/>}/>
  <Route path="/categorias" element={<Categories productos={productos}/>}/>
  <Route path="/ofertas" element={<Offers productos={productos} onAdd={add}/>}/>
  <Route path="/carrito" element={<Cart carrito={carrito} productos={productos} onRemove={remove} onClear={clearFromCart}/>}/>
  <Route path="/checkout" element={<Checkout onComplete={complete}/>}/>
  <Route path="/compra-exitosa" element={<Success pedido={pedido}/>}/>
  <Route path="/pago-fallido" element={<Failure/>}/>
  <Route path="/contacto" element={<Contact/>}/>
  <Route path="/admin" element={<Admin productos={productos} onCreate={create} onUpdate={update} onDelete={removeProduct}/>}/>
  <Route path="*" element={<main className="container py-5"><h1>Página no encontrada</h1></main>}/>
 </Routes><Footer/></>;
}
export default function App(){return <BrowserRouter><AppContent/></BrowserRouter>;}
