import { MemoryRouter } from "react-router-dom";
import ProductCard from "../components/ProductCard";
import ProductGrid from "../components/ProductGrid";
import Toast from "../components/Toast";
import Header from "../components/Header";
import Cart from "../pages/Cart";
import Checkout from "../pages/Checkout";
import Products from "../pages/Products";
import { PRODUCTOS_INICIALES } from "../data/productos";
import { montar, click, escribir, seleccionar, enviarFormulario, avanzar } from "./utils";

describe("ProductCard - renderizado, props y eventos", () => {
  let vista;
  afterEach(() => vista && vista.desmontar());

  const base = { id: 55, nombre: "Hoodie test", precio: 25000, categoria: "Hoodies", imagen: "/img/hoodienavy.jpg" };

  it("TC01 muestra el nombre y precio recibidos por props", () => {
    vista = montar(<ProductCard producto={base} onAdd={() => {}} />);
    expect(vista.host.textContent).toContain("Hoodie test");
    expect(vista.host.textContent).toContain("$25.000");
  });

  it("TC02 ejecuta onAdd con el id correcto al presionar el botón (mock con jasmine.createSpy)", () => {
    const onAdd = jasmine.createSpy("onAdd");
    vista = montar(<ProductCard producto={{ ...base, id: 77 }} onAdd={onAdd} />);
    click(vista.host.querySelector("button"));
    expect(onAdd).toHaveBeenCalledOnceWith(77);
  });

  it("TC03 renderizado condicional: muestra etiqueta, precio tachado y precio de oferta", () => {
    vista = montar(<ProductCard producto={{ ...base, precio: 59990, oferta: true, precioOferta: 49990 }} onAdd={() => {}} />);
    expect(vista.host.querySelector(".offer-label")).not.toBeNull();
    expect(vista.host.querySelector("del").textContent).toContain("59.990");
    expect(vista.host.querySelector(".product-price").textContent).toContain("49.990");
  });
});

describe("ProductCard - confirmación visual al añadir (estado local + temporizador)", () => {
  let vista;
  beforeEach(() => jasmine.clock().install());
  afterEach(() => { vista && vista.desmontar(); jasmine.clock().uninstall(); });

  it("TC15 el botón muestra \"¡Añadido!\" tras el clic y vuelve a su texto original", () => {
    vista = montar(<ProductCard producto={{ id: 1, nombre: "Hoodie", precio: 1000, categoria: "Hoodies", imagen: "/x.jpg" }} onAdd={() => {}} />);
    const boton = vista.host.querySelector("button");
    expect(boton.textContent).toBe("Añadir al carrito");
    click(boton);
    expect(boton.textContent).toContain("¡Añadido!");
    expect(boton.classList.contains("add-btn-ok")).toBeTrue();
    avanzar(1500);
    expect(boton.textContent).toBe("Añadir al carrito");
  });

  it("TC16 un segundo clic seguido reinicia el temporizador del mensaje", () => {
    vista = montar(<ProductCard producto={{ id: 1, nombre: "Hoodie", precio: 1000, categoria: "Hoodies", imagen: "/x.jpg" }} onAdd={() => {}} />);
    const boton = vista.host.querySelector("button");
    click(boton);
    avanzar(1000);
    click(boton);
    avanzar(1000); // han pasado 2000 ms desde el primer clic, pero solo 1000 desde el segundo
    expect(boton.textContent).toContain("¡Añadido!");
    avanzar(500);
    expect(boton.textContent).toBe("Añadir al carrito");
  });
});

describe("ProductGrid - listas y estado vacío", () => {
  let vista;
  afterEach(() => vista && vista.desmontar());

  it("TC04 muestra un mensaje cuando no hay productos", () => {
    vista = montar(<ProductGrid productos={[]} onAdd={() => {}} />);
    expect(vista.host.textContent).toContain("No hay productos para mostrar.");
  });

  it("TC05 renderiza una tarjeta por cada producto recibido", () => {
    vista = montar(<ProductGrid productos={PRODUCTOS_INICIALES.slice(0, 3)} onAdd={() => {}} />);
    expect(vista.host.querySelectorAll("article").length).toBe(3);
  });
});

describe("Cart - estado vacío, total, eventos y animaciones de salida", () => {
  let vista;
  // Reloj simulado: la salida animada (350 ms) se completa con avanzar() sin esperar de verdad.
  beforeEach(() => jasmine.clock().install());
  afterEach(() => { vista && vista.desmontar(); jasmine.clock().uninstall(); });

  const render = (carrito, onRemove = () => {}) =>
    montar(<MemoryRouter><Cart carrito={carrito} productos={PRODUCTOS_INICIALES} onRemove={onRemove} onClear={() => {}} /></MemoryRouter>);

  it("TC06 muestra el mensaje de carrito vacío", () => {
    vista = render([]);
    expect(vista.host.textContent).toContain("Tu carrito está vacío");
  });

  it("TC07 calcula el total (2 hoodies en oferta + 1 polera) y quita un ítem por posición", () => {
    const onRemove = jasmine.createSpy("onRemove");
    vista = render([2, 2, 3], onRemove);
    // 49.990 + 49.990 + 29.990 = 129.970
    expect(vista.host.querySelector("h2").textContent).toContain("129.970");
    click(vista.host.querySelector("button.btn-outline-danger"));
    // Primero se anima la salida de la fila; el padre solo es avisado cuando termina.
    expect(vista.host.querySelectorAll(".cart-row-leaving").length).toBe(1);
    expect(onRemove).not.toHaveBeenCalled();
    avanzar(400);
    expect(onRemove).toHaveBeenCalledOnceWith(0);
  });

  it("TC13 \"Vaciar carrito\" anima todas las filas y llama a onClear al terminar", () => {
    const onClear = jasmine.createSpy("onClear");
    vista = montar(<MemoryRouter><Cart carrito={[1, 2, 3]} productos={PRODUCTOS_INICIALES} onRemove={() => {}} onClear={onClear} /></MemoryRouter>);
    const botonVaciar = [...vista.host.querySelectorAll("button")].find(b => b.textContent === "Vaciar carrito");
    click(botonVaciar);
    expect(vista.host.querySelectorAll(".cart-row-leaving").length).toBe(3);
    expect([...vista.host.querySelectorAll("button")].every(b => b.disabled)).toBeTrue(); // evita doble clic durante la animación
    expect(onClear).not.toHaveBeenCalled();
    avanzar(600);
    expect(onClear).toHaveBeenCalledTimes(1);
  });
});

describe("Checkout - formulario controlado y validación", () => {
  let vista;
  afterEach(() => vista && vista.desmontar());

  it("TC08 muestra error y no completa la compra si faltan campos", () => {
    const onComplete = jasmine.createSpy("onComplete");
    vista = montar(<MemoryRouter><Checkout onComplete={onComplete} /></MemoryRouter>);
    enviarFormulario(vista.host.querySelector("form"));
    expect(vista.host.querySelector("[role=alert]").textContent).toContain("Completa todos los campos");
    expect(onComplete).not.toHaveBeenCalled();
  });

  it("TC09 actualiza el estado al escribir y entrega los datos a onComplete", () => {
    const onComplete = jasmine.createSpy("onComplete");
    vista = montar(<MemoryRouter><Checkout onComplete={onComplete} /></MemoryRouter>);
    const campo = nombre => vista.host.querySelector(`[name=${nombre}]`);
    escribir(campo("nombre"), "Ana Pérez");
    escribir(campo("correo"), "ana@correo.cl");
    escribir(campo("direccion"), "Av. Siempre Viva 123");
    escribir(campo("comuna"), "Santiago");
    expect(campo("nombre").value).toBe("Ana Pérez");
    enviarFormulario(vista.host.querySelector("form"));
    expect(onComplete).toHaveBeenCalledWith(jasmine.objectContaining({ nombre: "Ana Pérez", comuna: "Santiago", entrega: "Domicilio" }));
  });
});

describe("Products - búsqueda y filtros (estado + URL)", () => {
  let vista;
  afterEach(() => vista && vista.desmontar());

  const render = (ruta = "/productos") =>
    montar(<MemoryRouter initialEntries={[ruta]}><Products productos={PRODUCTOS_INICIALES} onAdd={() => {}} /></MemoryRouter>);

  it("TC10 filtra por nombre al escribir en el buscador", () => {
    vista = render();
    escribir(vista.host.querySelector("input"), "hoodie");
    expect(vista.host.textContent).toContain("6 producto(s) encontrados");
  });

  it("TC11 filtra por categoría al cambiar el select", () => {
    vista = render();
    seleccionar(vista.host.querySelector("select"), "Poleras");
    expect(vista.host.textContent).toContain("3 producto(s) encontrados");
  });

  it("TC12 aplica el filtro recibido por la URL (?categoria=Chaquetas)", () => {
    vista = render("/productos?categoria=Chaquetas");
    expect(vista.host.textContent).toContain("1 producto(s) encontrados");
  });
});

describe("Toast - aviso flotante temporal", () => {
  let vista;
  beforeEach(() => jasmine.clock().install());
  afterEach(() => { vista && vista.desmontar(); jasmine.clock().uninstall(); });

  const aviso = { id: 1, tipo: "exito", titulo: "¡Producto añadido con éxito!", texto: "Hoodie test · 1 producto en tu carrito", imagen: "/img/hoodienavy.jpg", enlace: { to: "/carrito", texto: "Ver carrito →" } };

  it("TC14 muestra el mensaje de éxito, sale animado y se cierra solo (onCerrar)", () => {
    const onCerrar = jasmine.createSpy("onCerrar");
    vista = montar(<MemoryRouter><Toast aviso={aviso} onCerrar={onCerrar} /></MemoryRouter>);
    expect(vista.host.textContent).toContain("¡Producto añadido con éxito!");
    expect(vista.host.querySelector("a").getAttribute("href")).toBe("/carrito");
    avanzar(2900);
    expect(vista.host.querySelector(".toast-out")).not.toBeNull();
    expect(onCerrar).not.toHaveBeenCalled();
    avanzar(300);
    expect(onCerrar).toHaveBeenCalledTimes(1);
  });

  it("TC17 el aviso de tipo \"quitar\" usa su estilo y el botón × lo cierra al instante", () => {
    const onCerrar = jasmine.createSpy("onCerrar");
    vista = montar(<MemoryRouter><Toast aviso={{ id: 2, tipo: "quitar", titulo: "Carrito vaciado", texto: "Quitaste todos los productos" }} onCerrar={onCerrar} /></MemoryRouter>);
    expect(vista.host.querySelector(".toast-quitar")).not.toBeNull();
    expect(vista.host.querySelector("img")).toBeNull();
    click(vista.host.querySelector(".toast-close"));
    expect(onCerrar).toHaveBeenCalledTimes(1);
  });

  it("TC18 sin aviso no renderiza ninguna tarjeta", () => {
    vista = montar(<MemoryRouter><Toast aviso={null} onCerrar={() => {}} /></MemoryRouter>);
    expect(vista.host.querySelector(".toast-card")).toBeNull();
  });
});

describe("Header - contador del carrito animado", () => {
  let vista;
  beforeEach(() => jasmine.clock().install());
  afterEach(() => { vista && vista.desmontar(); jasmine.clock().uninstall(); });

  const render = cantidad => <MemoryRouter><Header cantidad={cantidad} /></MemoryRouter>;

  it("TC19 muestra la cantidad en el contador y los 6 enlaces del menú", () => {
    vista = montar(render(3));
    expect(vista.host.querySelector(".cart-badge").textContent).toBe("3");
    expect(vista.host.querySelectorAll(".nav-link").length).toBe(6);
    expect(vista.host.querySelector(".cart-badge-bump")).toBeNull(); // no rebota al cargar
  });

  it("TC20 el contador rebota cuando cambia la cantidad y luego se detiene", () => {
    vista = montar(render(0));
    vista.actualizar(render(1));
    expect(vista.host.querySelector(".cart-badge").textContent).toBe("1");
    expect(vista.host.querySelector(".cart-badge-bump")).not.toBeNull();
    avanzar(700);
    expect(vista.host.querySelector(".cart-badge-bump")).toBeNull();
  });
});
