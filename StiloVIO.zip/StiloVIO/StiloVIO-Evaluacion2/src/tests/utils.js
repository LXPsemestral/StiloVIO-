// Utilidades compartidas por las pruebas de componentes (no es un archivo .spec).
import { createRoot } from "react-dom/client";
import { act } from "react";

globalThis.IS_REACT_ACT_ENVIRONMENT = true;

// Monta un elemento React en un <div> real del DOM de Chrome y devuelve el contenedor.
export function montar(elemento) {
  const host = document.createElement("div");
  document.body.appendChild(host);
  const root = createRoot(host);
  act(() => root.render(elemento));
  return {
    host,
    // Vuelve a renderizar el mismo árbol con nuevas props (simula un cambio de estado del padre).
    actualizar(nuevo) {
      act(() => root.render(nuevo));
    },
    desmontar() {
      act(() => root.unmount());
      host.remove();
    }
  };
}

// Avanza el reloj simulado de Jasmine dentro de act() para que React procese los cambios de estado.
export function avanzar(ms) {
  act(() => { jasmine.clock().tick(ms); });
}

export function click(elemento) {
  act(() => { elemento.dispatchEvent(new MouseEvent("click", { bubbles: true })); });
}

// React controla los inputs, por lo que se debe usar el setter nativo y luego disparar el evento.
function asignarValor(elemento, valor, evento) {
  const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(elemento), "value").set;
  setter.call(elemento, valor);
  act(() => { elemento.dispatchEvent(new Event(evento, { bubbles: true })); });
}
export const escribir = (input, valor) => asignarValor(input, valor, "input");
export const seleccionar = (select, valor) => asignarValor(select, valor, "change");

export function enviarFormulario(form) {
  act(() => { form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })); });
}
