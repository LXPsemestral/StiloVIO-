import {
  PRODUCTOS_INICIALES, obtenerProductos, crearProducto, actualizarProducto,
  eliminarProducto, restaurarProductosIniciales, precioFinal
} from "../data/productos";
import { obtenerCarrito, agregarCarrito, quitarDelCarrito, vaciarCarrito, calcularTotal } from "../data/carrito";

describe("Datos de productos - operaciones CRUD", () => {
  beforeEach(() => localStorage.clear());

  it("TU01 lee el catálogo inicial cuando no hay datos guardados", () => {
    expect(obtenerProductos().length).toBe(12);
  });

  it("TU02 crea y guarda un producto", () => {
    const nuevo = crearProducto({ nombre: "Polera prueba", precio: 10000, categoria: "Poleras", imagen: "/img/tshirtwhite.jpg" });
    expect(obtenerProductos().some(p => p.id === nuevo.id)).toBeTrue();
    expect(obtenerProductos().length).toBe(13);
  });

  it("TU03 actualiza un producto existente", () => {
    const primero = PRODUCTOS_INICIALES[0];
    actualizarProducto(primero.id, { nombre: "Hoodie actualizado" });
    expect(obtenerProductos().find(p => p.id === primero.id).nombre).toBe("Hoodie actualizado");
  });

  it("TU04 elimina un producto", () => {
    const primero = PRODUCTOS_INICIALES[0];
    eliminarProducto(primero.id);
    expect(obtenerProductos().some(p => p.id === primero.id)).toBeFalse();
  });

  it("TU05 restaura el catálogo inicial", () => {
    crearProducto({ nombre: "Temporal", precio: 1 });
    expect(restaurarProductosIniciales().length).toBe(12);
    expect(obtenerProductos().length).toBe(12);
  });
});

describe("Datos - uso de mocks y espías (Jasmine spies)", () => {
  beforeEach(() => localStorage.clear());

  it("TU06 guarda en localStorage con la clave correcta (espía sobre Storage.setItem)", () => {
    const espia = spyOn(Storage.prototype, "setItem").and.callThrough();
    crearProducto({ nombre: "Con espía", precio: 5000, categoria: "Poleras", imagen: "/img/tshirtwhite.jpg" });
    expect(espia).toHaveBeenCalledWith("stilovio-productos-v2", jasmine.any(String));
  });

  it("TU07 vuelve al catálogo inicial y a un carrito vacío si localStorage trae datos corruptos (mock de getItem)", () => {
    spyOn(Storage.prototype, "getItem").and.returnValue("{json-roto");
    expect(obtenerProductos().length).toBe(12);
    expect(obtenerCarrito()).toEqual([]);
  });
});

describe("Lógica de precios y carrito", () => {
  beforeEach(() => localStorage.clear());

  it("TU08 precioFinal devuelve el precio normal si el producto no está en oferta", () => {
    expect(precioFinal({ precio: 29990, oferta: false })).toBe(29990);
  });

  it("TU09 precioFinal devuelve el precio de oferta cuando corresponde", () => {
    expect(precioFinal({ precio: 59990, oferta: true, precioOferta: 49990 })).toBe(49990);
  });

  it("TU10 calcularTotal suma productos normales y en oferta e ignora ids inexistentes", () => {
    // id 1 = 59.990 (normal), id 2 = 49.990 (oferta), id 999 no existe
    expect(calcularTotal([1, 2, 999], PRODUCTOS_INICIALES)).toBe(109980);
  });

  it("TU11 agrega, quita y vacía el carrito persistiendo en localStorage", () => {
    agregarCarrito(3);
    agregarCarrito(5);
    expect(obtenerCarrito()).toEqual([3, 5]);
    quitarDelCarrito(0);
    expect(obtenerCarrito()).toEqual([5]);
    vaciarCarrito();
    expect(obtenerCarrito()).toEqual([]);
  });
});
