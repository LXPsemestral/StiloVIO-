import ProductCard from "./ProductCard";

export default function ProductGrid({ productos, onAdd }) {
  if (!productos.length) return <p className="empty-state">No hay productos para mostrar.</p>;
  return <div className="row g-4">{productos.map(p => <div className="col-12 col-sm-6 col-lg-4 col-xl-3" key={p.id}><ProductCard producto={p} onAdd={onAdd} /></div>)}</div>;
}
