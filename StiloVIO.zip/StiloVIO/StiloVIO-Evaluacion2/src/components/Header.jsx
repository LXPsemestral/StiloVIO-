import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";

export default function Header({ cantidad }) {
  // Cuando cambia la cantidad del carrito, el contador "rebota" un instante para llamar la atención.
  const [animar, setAnimar] = useState(false);
  const anterior = useRef(cantidad);

  useEffect(() => {
    if (anterior.current === cantidad) return undefined;
    anterior.current = cantidad;
    setAnimar(true);
    const fin = setTimeout(() => setAnimar(false), 600);
    return () => clearTimeout(fin);
  }, [cantidad]);

  return (
    <header className="site-header">
      <nav className="navbar navbar-expand-lg container px-3 py-3">
        <Link className="navbar-brand logo" to="/">StiloVIO</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal" aria-label="Abrir menú">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="menuPrincipal">
          <div className="navbar-nav ms-auto align-items-lg-center gap-lg-3">
            <NavLink className="nav-link" to="/">Inicio</NavLink>
            <NavLink className="nav-link" to="/productos">Productos</NavLink>
            <NavLink className="nav-link" to="/categorias">Categorías</NavLink>
            <NavLink className="nav-link" to="/ofertas">Ofertas</NavLink>
            <NavLink className="nav-link" to="/contacto">Contacto</NavLink>
            <NavLink className="nav-link" to="/carrito">
              Carrito <span key={cantidad} className={`cart-badge${animar ? " cart-badge-bump" : ""}`}>{cantidad}</span>
            </NavLink>
            <NavLink className="btn btn-outline-brand btn-sm" to="/admin">Administrar</NavLink>
          </div>
        </div>
      </nav>
    </header>
  );
}
