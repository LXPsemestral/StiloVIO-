import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// Aviso flotante animado (entra deslizando, muestra una barra de tiempo y sale solo).
// Recibe un objeto "aviso" { id, tipo, titulo, texto, imagen, enlace } o null.
export const DURACION_AVISO = 2800;
const DURACION_SALIDA = 350;

export default function Toast({ aviso, onCerrar }) {
  const [idSaliendo, setIdSaliendo] = useState(null);

  useEffect(() => {
    if (!aviso) return undefined;
    const iniciarSalida = setTimeout(() => setIdSaliendo(aviso.id), DURACION_AVISO);
    const cerrar = setTimeout(onCerrar, DURACION_AVISO + DURACION_SALIDA);
    return () => { clearTimeout(iniciarSalida); clearTimeout(cerrar); };
  }, [aviso]);

  return (
    <div className="toast-wrap" aria-live="polite">
      {aviso && (
        <div key={aviso.id} className={`toast-card toast-${aviso.tipo}${idSaliendo === aviso.id ? " toast-out" : ""}`}>
          <span className="toast-icon" aria-hidden="true">
            {aviso.tipo === "quitar" ? (
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12h10l1-12M9 7V4h6v3" /></svg>
            ) : (
              <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path className="toast-check" d="M5 12.5l4.5 4.5L19 7.5" /></svg>
            )}
          </span>
          {aviso.imagen && <img className="toast-thumb" src={aviso.imagen} alt="" />}
          <div className="toast-body">
            <strong>{aviso.titulo}</strong>
            <span>{aviso.texto}</span>
            {aviso.enlace && <Link to={aviso.enlace.to} onClick={onCerrar}>{aviso.enlace.texto}</Link>}
          </div>
          <button type="button" className="toast-close" aria-label="Cerrar aviso" onClick={onCerrar}>×</button>
          <span className="toast-progress" style={{ animationDuration: `${DURACION_AVISO}ms` }} />
        </div>
      )}
    </div>
  );
}
