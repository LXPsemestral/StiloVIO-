import { useEffect, useRef, useState } from "react";
import { precioCLP, precioFinal } from "../data/productos";

export default function ProductCard({ producto, onAdd }) {
  const precio = precioFinal(producto);
  // Estado local: el botón confirma visualmente (verde + "¡Añadido!") durante un instante.
  const [agregado, setAgregado] = useState(false);
  const temporizador = useRef(null);
  useEffect(() => () => clearTimeout(temporizador.current), []);

  function agregar() {
    onAdd(producto.id);
    setAgregado(true);
    clearTimeout(temporizador.current);
    temporizador.current = setTimeout(() => setAgregado(false), 1400);
  }

  return (
    <article className="card product-card h-100">
      {producto.oferta && <span className="offer-label">Oferta</span>}
      <img src={producto.imagen} className="card-img-top product-image" alt={producto.nombre} />
      <div className="card-body d-flex flex-column">
        <h3 className="h5">{producto.nombre}</h3>
        <p className="text-muted small mb-1">{producto.categoria}</p>
        <div className="mb-3">
          {producto.oferta && <del className="text-muted me-2">{precioCLP(producto.precio)}</del>}
          <strong className="product-price">{precioCLP(precio)}</strong>
        </div>
        <button className={`btn btn-brand mt-auto add-btn${agregado ? " add-btn-ok" : ""}`} onClick={agregar}>
          {agregado ? "✓ ¡Añadido!" : "Añadir al carrito"}
        </button>
      </div>
    </article>
  );
}
