export default function Footer() {
  return <footer className="site-footer mt-5"><div className="container py-4 d-flex flex-wrap justify-content-between gap-2"><span>© 2026 StiloVIO · Tienda de ropa</span><span>Proyecto académico</span></div></footer>;
}
