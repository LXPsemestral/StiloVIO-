const PRODUCTOS_INICIALES = [
  { id: 1, nombre: "Hoodie wolfgrey", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodiewolfgrey.jpg", oferta: false, destacado: true },
  { id: 2, nombre: "Hoodie burgundy", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodieburgundy.jpg", oferta: true, precioOferta: 49990, destacado: true },
  { id: 3, nombre: "T shirt navy", precio: 29990, categoria: "Poleras", imagen: "/img/tshirtnavy.jpg", oferta: false, destacado: true },
  { id: 4, nombre: "Jacket rain black", precio: 89990, categoria: "Chaquetas", imagen: "/img/jacketrainblack.jpg", oferta: true, precioOferta: 74990 },
  { id: 5, nombre: "Hoodie light blue", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodielightblue.jpg", oferta: false },
  { id: 6, nombre: "T shirt blackandblack", precio: 29990, categoria: "Poleras", imagen: "/img/tshirtblackandblack.jpg", oferta: false },
  { id: 7, nombre: "T shirt white", precio: 29990, categoria: "Poleras", imagen: "/img/tshirtwhite.jpg", oferta: false },
  { id: 8, nombre: "Hoodie taupe", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodietaupe.jpg", oferta: false },
  { id: 9, nombre: "Hoodie navy", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodienavy.jpg", oferta: false },
  { id: 10, nombre: "Hoodie purple", precio: 59990, categoria: "Hoodies", imagen: "/img/hoodielightpurple.jpg", oferta: false },
  { id: 11, nombre: "Dress black", precio: 49990, categoria: "Vestidos", imagen: "/img/vestidoblack.jpg", oferta: true, precioOferta: 39990 },
  { id: 12, nombre: "Jeans baggy", precio: 39990, categoria: "Pantalones", imagen: "/img/jeansbaggy.jpg", oferta: false }
];

const CLAVE_PRODUCTOS = "stilovio-productos-v2";

export function obtenerProductos() {
  try {
    const datos = JSON.parse(localStorage.getItem(CLAVE_PRODUCTOS));
    return Array.isArray(datos) ? datos : PRODUCTOS_INICIALES;
  } catch {
    return PRODUCTOS_INICIALES;
  }
}

export function guardarProductos(productos) {
  localStorage.setItem(CLAVE_PRODUCTOS, JSON.stringify(productos));
}

export function crearProducto(datos) {
  const productos = obtenerProductos();
  const nuevo = { ...datos, id: Date.now(), oferta: Boolean(datos.oferta) };
  guardarProductos([...productos, nuevo]);
  return nuevo;
}

export function actualizarProducto(id, cambios) {
  const productos = obtenerProductos().map(p => p.id === id ? { ...p, ...cambios } : p);
  guardarProductos(productos);
  return productos;
}

export function eliminarProducto(id) {
  const productos = obtenerProductos().filter(p => p.id !== id);
  guardarProductos(productos);
  return productos;
}

export function restaurarProductosIniciales() {
  localStorage.removeItem(CLAVE_PRODUCTOS);
  return [...PRODUCTOS_INICIALES];
}

export function precioFinal(producto) {
  return producto.oferta && producto.precioOferta ? producto.precioOferta : producto.precio;
}

export function precioCLP(valor) {
  return new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(valor);
}

export { PRODUCTOS_INICIALES };
