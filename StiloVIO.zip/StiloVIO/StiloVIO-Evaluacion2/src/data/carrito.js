import { precioFinal } from "./productos";

const CLAVE_CARRITO = "stilovio-carrito-v2";

export function obtenerCarrito() {
  try {
    const datos = JSON.parse(localStorage.getItem(CLAVE_CARRITO));
    return Array.isArray(datos) ? datos : [];
  } catch {
    return [];
  }
}

export function guardarCarrito(carrito) {
  localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
}

export function agregarCarrito(id) {
  const carrito = obtenerCarrito();
  carrito.push(id);
  guardarCarrito(carrito);
  return carrito;
}

export function quitarDelCarrito(posicion) {
  const carrito = obtenerCarrito();
  carrito.splice(posicion, 1);
  guardarCarrito(carrito);
  return carrito;
}

export function vaciarCarrito() {
  guardarCarrito([]);
}

export function calcularTotal(carrito, productos) {
  return carrito.reduce((suma, id) => {
    const producto = productos.find(p => p.id === id);
    return producto ? suma + precioFinal(producto) : suma;
  }, 0);
}
